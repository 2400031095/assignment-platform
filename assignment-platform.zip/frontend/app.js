// Simple client-side app:
// - localStorage-based accounts
// - session stored in localStorage 'session'
// - auto-redirect to dashboard pages depending on role
// - optional Firebase placeholder (see README)

const apiBase = 'http://localhost:4000/api'; // backend for file upload + grading

// helpers
const $ = id => document.getElementById(id);

// show/hide forms
$('#show-signup').addEventListener('click', e => { e.preventDefault(); toggleForms('signup'); });
$('#show-login').addEventListener('click', e => { e.preventDefault(); toggleForms('login'); });
function toggleForms(form){ document.querySelectorAll('.form').forEach(f => f.classList.remove('active')); if(form==='signup') $('#signup-form').classList.add('active'); else $('#login-form').classList.add('active'); }

// init
(function(){
  // if logged in -> redirect
  const session = JSON.parse(localStorage.getItem('session') || 'null');
  if(session && session.email && session.role){
    window.location.href = session.role === 'teacher' ? 'teacher.html' : 'student.html';
    return;
  }
  // show login form by default
  toggleForms('login');
})();

// Signup
$('#signup-form').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const name = $('#signup-name').value.trim();
  const email = $('#signup-email').value.trim().toLowerCase();
  const password = $('#signup-password').value;
  const role = $('#signup-role').value;
  if(!email || !password) return alert('Provide email & password');
  let users = JSON.parse(localStorage.getItem('users') || '[]');
  if(users.find(u=>u.email===email)) return alert('Account exists. Login instead.');
  const user = { name, email, password, role };
  users.push(user);
  localStorage.setItem('users', JSON.stringify(users));
  localStorage.setItem('session', JSON.stringify({ email, role, name }));
  window.location.href = (role === 'teacher') ? 'teacher.html' : 'student.html';
});

// Login
$('#login-form').addEventListener('submit', ev => {
  ev.preventDefault();
  const email = $('#login-email').value.trim().toLowerCase();
  const password = $('#login-password').value;
  const role = $('#login-role').value;
  const users = JSON.parse(localStorage.getItem('users') || '[]');
  const user = users.find(u => u.email === email && u.password === password && u.role === role);
  if(!user) return alert('Invalid credentials or wrong role.');
  localStorage.setItem('session', JSON.stringify({ email: user.email, role: user.role, name: user.name }));
  window.location.href = (user.role === 'teacher') ? 'teacher.html' : 'student.html';
});
