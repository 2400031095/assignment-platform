// Student dashboard script
(function(){
  const session = JSON.parse(localStorage.getItem('session') || 'null');
  if(!session) return window.location.href = 'index.html';
  if(session.role !== 'student') return window.location.href = (session.role==='teacher') ? 'teacher.html' : 'index.html';
  document.getElementById('welcome').innerText = `Hi, ${session.name || session.email}`;
  document.getElementById('logout').addEventListener('click', ()=>{
    localStorage.removeItem('session'); window.location.href='index.html';
  });

  const subsList = document.getElementById('subs-list');
  function render(){
    const all = JSON.parse(localStorage.getItem('submissions') || '[]');
    const mine = all.filter(s=>s.email===session.email);
    if(mine.length===0) subsList.innerHTML = '<p class="muted">No submissions yet.</p>';
    else subsList.innerHTML = mine.map(s=>`<div style="padding:8px;border-radius:8px;border:1px solid #f0f0f0;margin-bottom:8px">
      <strong>${s.title}</strong><br/>
      Status: ${s.status || 'pending'} <br/>
      Grade: ${s.grade || '-'} <br/>
      Feedback: ${s.feedback || '-'} <br/>
      <a href="${s.fileUrl || '#'}" target="_blank">Download file</a>
    </div>`).join('');
  }
  render();

  // handle upload: we save locally and also post to backend /api/upload (if running)
  document.getElementById('upload-form').addEventListener('submit', async ev=>{
    ev.preventDefault();
    const title = document.getElementById('title').value.trim();
    const fileInput = document.getElementById('file');
    if(!title||fileInput.files.length===0) return alert('Provide title and file');
    const file = fileInput.files[0];

    // create a local object URL and save as submission in localStorage
    const reader = new FileReader();
    reader.onload = async function(e){
      const blobUrl = e.target.result;
      const submissions = JSON.parse(localStorage.getItem('submissions') || '[]');
      const id = 'sub_' + Date.now();
      const sub = { id, title, email: session.email, name: session.name, status:'pending', fileName:file.name, fileUrl:blobUrl, createdAt: Date.now() };
      submissions.push(sub);
      localStorage.setItem('submissions', JSON.stringify(submissions));
      render();
      document.getElementById('upload-msg').innerText = 'Saved locally. If backend is running, also uploading...';

      // try backend upload
      try{
        const form = new FormData();
        form.append('file', file);
        form.append('title', title);
        form.append('email', session.email);
        const res = await fetch('http://localhost:4000/api/upload', { method:'POST', body: form });
        if(res.ok){
          document.getElementById('upload-msg').innerText = 'Uploaded to backend successfully.';
        } else document.getElementById('upload-msg').innerText = 'Backend upload failed (no server?).';
      }catch(err){ /* ignore */ }
    };
    reader.readAsDataURL(file);
  });
})();
