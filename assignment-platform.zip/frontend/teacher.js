// Teacher dashboard script
(function(){
  const session = JSON.parse(localStorage.getItem('session') || 'null');
  if(!session) return window.location.href = 'index.html';
  if(session.role !== 'teacher') return window.location.href = (session.role==='student') ? 'student.html' : 'index.html';
  document.getElementById('logout').addEventListener('click', ()=>{ localStorage.removeItem('session'); window.location.href='index.html'; });

  const pending = document.getElementById('pending-list'), graded = document.getElementById('graded-list');

  function render(){
    const subs = JSON.parse(localStorage.getItem('submissions') || '[]');
    const pend = subs.filter(s=>!s.grade);
    const grad = subs.filter(s=>s.grade);
    pending.innerHTML = pend.length ? pend.map(s=>renderPending(s)).join('') : '<p class="muted">No pending.</p>';
    graded.innerHTML = grad.length ? grad.map(s=>renderGraded(s)).join('') : '<p class="muted">No graded yet.</p>';
  }

  function renderPending(s){
    return `<div style="padding:8px;border-radius:8px;border:1px solid #f0f0f0;margin-bottom:8px">
      <strong>${s.title}</strong> by ${s.name || s.email}<br/>
      <a href="${s.fileUrl||'#'}" target="_blank">Download</a><br/>
      <label>Grade: <input data-id="${s.id}" class="grade-input" /></label>
      <label>Feedback: <input data-id="${s.id}" class="fb-input" /></label>
      <button data-id="${s.id}" class="grade-btn btn" style="margin-top:8px">Submit grade</button>
    </div>`;
  }
  function renderGraded(s){
    return `<div style="padding:8px;border-radius:8px;border:1px solid #f0f0f0;margin-bottom:8px">
      <strong>${s.title}</strong> by ${s.name || s.email}<br/>
      Grade: ${s.grade} <br/> Feedback: ${s.feedback || '-'} <br/>
      <a href="${s.fileUrl||'#'}" target="_blank">Download</a>
    </div>`;
  }

  document.addEventListener('click', async (e)=>{
    if(e.target.classList.contains('grade-btn')){
      const id = e.target.dataset.id;
      const gradeInput = document.querySelector(`.grade-input[data-id="${id}"]`);
      const fbInput = document.querySelector(`.fb-input[data-id="${id}"]`);
      const grade = gradeInput.value.trim();
      const feedback = fbInput.value.trim();
      if(!grade) return alert('Provide grade');
      const subs = JSON.parse(localStorage.getItem('submissions') || '[]');
      const idx = subs.findIndex(s=>s.id===id);
      if(idx===-1) return alert('Submission not found');
      subs[idx].grade = grade;
      subs[idx].feedback = feedback;
      subs[idx].status = 'graded';
      localStorage.setItem('submissions', JSON.stringify(subs));
      render();

      // post to backend (if running)
      try{
        await fetch('http://localhost:4000/api/grade', {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ id, grade, feedback })
        });
      }catch(err){}
    }
  });

  render();
})();
