const express = require('express');
const cors = require('cors');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

const DATA_PATH = path.join(__dirname, 'data.json');
if(!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, JSON.stringify({ users:[], assignments:[] }, null, 2));

// storage for uploads
const UPLOADS = path.join(__dirname, 'uploads');
if(!fs.existsSync(UPLOADS)) fs.mkdirSync(UPLOADS);

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, UPLOADS);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname.replace(/\s+/g,'_'));
  }
});
const upload = multer({ storage });

function readData(){ return JSON.parse(fs.readFileSync(DATA_PATH)); }
function writeData(d){ fs.writeFileSync(DATA_PATH, JSON.stringify(d, null, 2)); }

app.post('/api/upload', upload.single('file'), (req, res) => {
  try{
    const { title, email } = req.body;
    const file = req.file;
    const d = readData();
    const id = 'srv_' + Date.now();
    const record = {
      id, title, email, filePath: file ? '/uploads/' + path.basename(file.path) : null,
      createdAt: Date.now(), status:'pending'
    };
    d.assignments.push(record);
    writeData(d);
    res.json({ ok:true, record });
  }catch(err){
    console.error(err);
    res.status(500).json({ ok:false, error:err.message });
  }
});

app.post('/api/grade', (req,res)=>{
  const { id, grade, feedback } = req.body;
  const d = readData();
  const idx = d.assignments.findIndex(a=>a.id===id);
  if(idx===-1) return res.status(404).json({ ok:false, error:'not found' });
  d.assignments[idx].grade = grade;
  d.assignments[idx].feedback = feedback;
  d.assignments[idx].status = 'graded';
  writeData(d);
  res.json({ ok:true, assignment:d.assignments[idx] });
});

// serve uploaded files
app.use('/uploads', express.static(UPLOADS));

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log('Backend listening on', PORT));
