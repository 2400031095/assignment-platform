# Cute Assignments — Demo Project

This is a minimal full-stack demo for an **assignment submission and grading system** with a cute animated UI.

Features included:
- Cute gradient background & animated card UI
- Login & Signup pages (localStorage-based accounts)
- Separate dashboards for **teacher** and **student**
- Auto-redirect based on role, and logout
- Student file upload (saved locally in browser, and attempts backend upload)
- Teacher grading panel (grades saved to localStorage and optionally posted to backend)
- Backend (Node/Express) with file upload and simple JSON storage
- Firebase authentication: optional — placeholder included and instructions below

> This is a demo meant to run locally. Replace placeholders with your Firebase config if you want to enable Firebase auth.

## Quick start

### Backend
1. `cd backend`
2. `npm install`
3. `npm run start` (default runs on port 4000)
   - Uploads are saved to `backend/uploads`
   - Data stored in `backend/data.json` (users and assignments)

### Frontend
1. Serve the `frontend` folder (open `frontend/index.html` directly in a browser or use a static server).
2. Create accounts with Sign up (choose teacher or student).
3. Student can upload assignments (saved to localStorage; if backend is running, will try to upload to `http://localhost:4000/api/upload`).
4. Teacher can grade submissions and feedback will be saved.

### Firebase (optional)
- The frontend includes a placeholder area where you can add Firebase config and swap the local auth calls with Firebase Auth SDK.
- For production, do not store sensitive keys in client-side code.

## Notes
- This demo focuses on the requested features. For production usage you should:
  - Use a proper database (Postgres, MongoDB, etc.)
  - Secure authentication (password hashing, HTTPS)
  - Validate/scan uploaded files, rate limits, and permissions
